

function gotoChat(){
	$('.div-modal-chat').toggle();
}
function closeChat(){
	$('.div-modal-chat').hide();
}