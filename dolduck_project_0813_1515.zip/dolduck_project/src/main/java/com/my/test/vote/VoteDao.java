package com.my.test.vote;

public class VoteDao {
	
	public int update(String starName, int page) {
		return 0;
	}
	public int insert(String starName, int page) {
		return 0;
	}
}
