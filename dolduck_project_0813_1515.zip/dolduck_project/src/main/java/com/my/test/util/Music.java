package com.my.test.util;

public class Music {

	private String rank;
	private String rank_change;
	private String thumb;
	private String title;
	private String singer;
	private String album;
	

	public String getRank() { 
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getRank_change() {
		return rank_change;
	}
	public void setRank_change(String rank_change) {
		this.rank_change = rank_change;
	}
	public String getThumb() {
		return thumb;
	}
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer = singer;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
	
}
